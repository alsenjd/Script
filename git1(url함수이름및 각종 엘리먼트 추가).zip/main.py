# -*- conding: utf-8 -*-

from module1 import *

def main():

    while(True):
        print("1.PrintAll\n2.Search.\n3.Search and send email\n4.save to File.\n")
        menuNum = input("selletMenu(1~4):")










if __name__ == "__main__":

    main()